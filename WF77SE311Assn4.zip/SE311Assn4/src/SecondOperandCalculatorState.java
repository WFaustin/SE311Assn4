
public class SecondOperandCalculatorState implements CalculatorState{

	@Override
	public void doAction(CalculatorStateContext context) {
		// TODO Auto-generated method stub
		System.out.println("At the second operand state!"); 
	}

}
