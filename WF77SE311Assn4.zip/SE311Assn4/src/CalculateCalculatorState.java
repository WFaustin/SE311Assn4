
public class CalculateCalculatorState implements CalculatorState{

	@Override
	public void doAction(CalculatorStateContext context) {
		// TODO Auto-generated method stub
		System.out.println("At the calculate state!"); 
	}
	
	

}
