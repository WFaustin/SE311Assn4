
public class StartCalculatorState implements CalculatorState {

	public void doAction(CalculatorStateContext context) {
		// TODO Auto-generated method stub
		System.out.println("At the start state!"); 
	}

}
