
//Server side should be using the state pattern. 
public interface CalculatorState {
	
	public void doAction(CalculatorStateContext context); 
	
}
