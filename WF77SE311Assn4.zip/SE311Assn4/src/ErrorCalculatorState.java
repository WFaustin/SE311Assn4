
public class ErrorCalculatorState implements CalculatorState{

	public void doAction(CalculatorStateContext context) {
		// TODO Auto-generated method stub
		System.out.println("At the error state! Please clear to reset to the start state."); 
	}
	

}
