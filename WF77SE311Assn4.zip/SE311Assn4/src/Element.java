
public interface Element {

	public void accept(Visitor v); 
	
}
